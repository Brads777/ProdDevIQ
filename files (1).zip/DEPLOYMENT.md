©2026 Brad Scheller
E-mail: gscheller@mba1983.hbs.edu

---
name: mkt2700-pipeline-deployment-guide
description: Deployment instructions for the MKT2700 AI-Augmented Product Development Pipeline skill system. Covers setup for both Claude.ai Projects and Claude Code.
---

# MKT2700 Pipeline — Deployment Guide

## Quick Start

### Option A: Claude.ai Project Setup

1. **Create a new Claude.ai Project** called "MKT2700 Semester Project"
2. **Set Project Instructions** — paste the contents of `orchestrator/SKILL.md`
3. **Add to Project Knowledge** — upload all 7 phase SKILL.md files:
   - `phase-1-strategic-foundation/SKILL.md`
   - `phase-2-rubric-creation/SKILL.md`
   - `phase-3-concept-discovery/SKILL.md`
   - `phase-4-deep-research/SKILL.md`
   - `phase-5-concept-evaluation/SKILL.md`
   - `phase-6-refinement-specification/SKILL.md`
   - `phase-7-prd-generation/SKILL.md`
4. **Start a new chat** and say: "Start project"
5. Follow the orchestrator's guidance through each phase
6. When prompted, open new chats within the same Project for each phase

### Option B: Claude Code Setup

```bash
# 1. Install Claude Code (if not already installed)
npm install -g @anthropic-ai/claude-code

# 2. Create project directory
mkdir mkt2700-project && cd mkt2700-project

# 3. Copy all skill files into the project
cp -r /path/to/mkt2700-pipeline/* .

# 4. Initialize the project
echo "# MKT2700 Semester Project" > plan.md
echo "## Status: Phase 1 — Not Started" >> plan.md

# 5. Start Claude Code
claude

# 6. Say: "Read the orchestrator skill and start Phase 1"
```

#### Optional: MCP Server Configuration

Create `.claude/mcp_config.json` for tool integrations:

```json
{
  "mcpServers": {
    "notebooklm": {
      "command": "npx",
      "args": ["-y", "notebooklm-mcp-server"]
    }
  }
}
```

## Pipeline Overview

```
Phase 1: Strategic Foundation
    ↓ (Strategic Brief)
Phase 2: Rubric Creation
    ↓ (Locked Evaluation Rubric)
Phase 3: Concept Discovery
    ↓ (30-40 Concept Candidates)
Phase 4: Deep Research
    ↓ (Research Repository)        ← Gate: NotebookLM notebooks complete?
Phase 5: Concept Evaluation
    ↓ (Scored + Ranked Concepts)   ← Gate: <90% kill, 90-95% revise, >95% continue
Phase 6: Refinement & Specification
    ↓ (SCAMPER + KANO Classified)  ← Gate: All 5 KANO categories complete?
Phase 7: PRD Generation
    ↓ (Final PRD — .md + .docx)
```

## Artifacts Produced

| Phase | Artifact File | Description |
|-------|--------------|-------------|
| 1 | `strategic-brief.md` | Company profile + PESTEL/SWOT/VRIO/Porter's analysis |
| 2 | `evaluation-rubric.md` | Weighted criteria with 0-4 level definitions |
| 3 | `concept-candidates.md` | Ranked list of 30-40 concept candidates |
| 4 | `research-repository.md` | Deep research dossiers per concept |
| 5 | `evaluation-results.md` | Multi-model scored evaluations + rankings |
| 6 | `refined-concept.md` | SCAMPER refinements + KANO classification |
| 7 | `product-requirements-document.md` | Full PRD with all 10 sections |

## Parallel Tool Requirements

Students need accounts for:
- **Claude.ai** (Pro or Team) — Opus 4.5 access required
- **Google NotebookLM** — free with Google account
- **Perplexity Pro** — paid tier for deep research
- **Google AI Studio** — free Gemini 3 Pro access

## Timeline

| Day | Milestone |
|-----|-----------|
| Feb 5 | Pipeline walkthrough video; begin Phase 1 |
| Feb 6 | Complete Phase 1 + 2; begin Phase 3 discovery |
| Feb 7 | Complete Phase 3; begin Phase 4 deep research |
| Feb 8 | Complete Phase 4 + 5; select final concept |
| Feb 9 | Complete Phase 6; begin Phase 7 PRD |
| Feb 10 | Finalize and submit PRD + all artifacts |
