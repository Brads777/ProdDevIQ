©2026 Brad Scheller
E-mail: gscheller@mba1983.hbs.edu

---
name: phase-5-concept-evaluation
description: Phase 5 of the MKT2700 AI-Augmented Product Development Pipeline. Evaluates concept candidates against the weighted rubric using a multi-model approach — Claude scores first, then Gemini scores independently, then an LLM Council compares and reconciles results. Applies decision thresholds (kill <90%, revise 90-95%, continue >95%). Triggers on "begin phase 5," "evaluate concepts," "concept evaluation," or "score concepts." Requires rubric and research repository as inputs.
---

# Phase 5: Concept Evaluation

## Purpose

Rigorously evaluate all researched concepts against the locked rubric using a multi-model approach to reduce single-model bias. Produce final scores with improvement recommendations for concepts in the revise band.

## Prerequisites

Requires:
- `evaluation-rubric.md` from Phase 2 (LOCKED — no changes permitted)
- `research-repository.md` from Phase 4
- `strategic-brief.md` from Phase 1

## Process

### Step 1: Claude Evaluation (Primary)

For each concept, score against every rubric criterion:

1. Apply must-have constraints first. If any constraint fails → KILL immediately.
2. For each criterion in the rubric:
   - Review the research evidence for this concept + criterion
   - Assign a score (0-4) based on the level definitions in the rubric
   - Provide a 1-2 sentence justification citing specific evidence
3. Calculate weighted score:
   ```
   Concept Score = Σ(score_i × weight_i) ÷ Σ(4 × weight_i) × 100%
   ```
4. Apply decision threshold:
   - < 90% → KILL
   - 90-95% → REVISE
   - > 95% → CONTINUE

Present results as a structured scorecard:

```markdown
### Concept: [Name]
**Must-Have Constraints:** ✅ All passed / ❌ Failed: [which one]

| # | Criterion | Weight | Score | Weighted | Justification |
|---|-----------|--------|-------|----------|---------------|
| 1 | [name] | [w] | [0-4] | [s×w] | [evidence-based reason] |
| ... | | | | | |
| **TOTAL** | | **[Σw]** | | **[Σs×w]** | |

**Final Score: [X]% ([Σs×w] / [Σ4×w] × 100)**
**Decision: KILL / REVISE / CONTINUE**
```

### Step 2: Gemini Evaluation (Independent)

Generate a formatted prompt for students to paste into Gemini (AI Studio):

```
You are evaluating product concepts against a scoring rubric. For each concept, score each criterion on a 0-4 scale and justify with evidence.

RUBRIC:
[paste full rubric with criterion definitions]

CONCEPT: [name]
RESEARCH EVIDENCE:
[paste research dossier for this concept]

For each criterion, provide:
1. Score (0-4) with justification
2. Confidence level (High/Medium/Low)
3. Any evidence gaps that affect your scoring

Calculate the final weighted score as: Σ(score × weight) ÷ Σ(4 × weight) × 100%
```

Students run this for each surviving concept and bring Gemini's scores back.

### Step 3: LLM Council Reconciliation

Compare Claude and Gemini scores. For each concept:

1. **Agreement check:** Where do models agree (within 1 point)?
2. **Divergence analysis:** Where do models disagree by 2+ points?
3. **Resolution:** For each divergence:
   - Review the evidence both models cited
   - Determine which model's reasoning is stronger
   - Assign a final reconciled score with explanation
4. **Confidence weighting:** Flag criteria where both models had low confidence (insufficient evidence)

The final reconciled score becomes the official evaluation.

### Step 4: Improvement Analysis (Revise Band)

For concepts scoring 90-95% (REVISE band):

1. Identify the 3-5 criteria with the lowest scores relative to their weights
2. For each, calculate: "If this criterion improved by 1 point, the overall score would increase by X%"
3. Rank improvement opportunities by score impact
4. Provide specific, actionable suggestions for how to improve each criterion

```markdown
### Improvement Roadmap: [Concept Name]
Current Score: [X]%

| Priority | Criterion | Current | Target | Score Impact | Suggested Improvement |
|----------|-----------|---------|--------|-------------|----------------------|
| 1 | [name] | 2 | 3 | +2.3% | [specific action] |
| 2 | [name] | 1 | 3 | +1.8% | [specific action] |
| ... | | | | | |

**Projected Score if All Improvements Made: [Y]%**
```

### Step 5: Final Rankings

Produce the final ranked list:

```markdown
## Final Evaluation Results

### CONTINUE (>95%)
1. [Concept] — [Score]% ✅
2. ...

### REVISE (90-95%)
3. [Concept] — [Score]% ⚠️ (see improvement roadmap)
4. ...

### KILL (<90%)
5. [Concept] — [Score]% ❌
6. ...

### Recommendation
Based on evaluation, the team should advance [Concept X] as the primary concept
and consider [Concept Y] as an alternative if improvements are made.
```

## Output: Evaluation Results Artifact

Save as `evaluation-results.md`:

```markdown
# Concept Evaluation Results: [Company Name]

## Evaluation Summary
- Concepts evaluated: [N]
- CONTINUE (>95%): [N]
- REVISE (90-95%): [N]
- KILL (<90%): [N]

## Detailed Scorecards
[Full scorecards for each concept — Claude, Gemini, and reconciled]

## Model Agreement Analysis
[Summary of where Claude and Gemini agreed/diverged]

## Improvement Roadmaps
[For each REVISE-band concept]

## Final Rankings
[Ordered list with decisions]

## Selected Concept for Phase 6: [Name]
Justification: [why this concept advances]
```

## Handoff

1. Save the evaluation results artifact.
2. Confirm the team's selected concept (should be highest-scoring CONTINUE concept).
3. Instruct: "Open a new chat and say 'Begin Phase 6 — Refinement.' Bring your evaluation results and the research dossier for your selected concept."
