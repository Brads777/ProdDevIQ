---
name: phase-7-prd-generation
description: Phase 7 of the MKT2700 AI-Augmented Product Development Pipeline. Generates a comprehensive Product Requirements Document (PRD) from all prior phase artifacts. Produces both markdown and Word (.docx) formats. Triggers on "begin phase 7," "generate PRD," "product requirements document," or "create PRD." Requires all prior phase artifacts. NOTE — This skill will be updated when the instructor's PRD template skill is provided.
---

# Phase 7: PRD Generation

## Purpose

Synthesize all artifacts from Phases 1-6 into a professional Product Requirements Document (PRD) that serves as the team's final deliverable. The PRD must be comprehensive, evidence-based, and structured for implementation.

## Prerequisites

Requires ALL prior artifacts:
- `strategic-brief.md` (Phase 1)
- `evaluation-rubric.md` (Phase 2)
- `concept-candidates.md` (Phase 3)
- `research-repository.md` (Phase 4)
- `evaluation-results.md` (Phase 5)
- `refined-concept.md` (Phase 6)

## PRD Structure

### Section 1: Executive Summary
- Product name and one-line description
- Problem statement (1-2 paragraphs)
- Target market and user persona summary
- Key value proposition
- Strategic fit (why THIS product for THIS company)
- Expected outcomes and success metrics

### Section 2: Strategic Context
Synthesize from Phase 1 Strategic Brief:
- Company situation analysis (condensed PESTEL, Porter's, SWOT)
- Competitive positioning and disruption opportunity
- Portfolio strategy alignment
- Why this product was selected over [N] alternatives evaluated

### Section 3: Problem Statement & Market Opportunity
Synthesize from Phase 3 discovery + Phase 4 research:
- Detailed problem description with evidence
- Market size (TAM/SAM/SOM with sources)
- Current solutions and their limitations
- Customer pain points with direct evidence (quotes, metrics)
- Market trends supporting this opportunity

### Section 4: Target Users
From research and KANO interviews:
- Primary user persona(s) with demographics, behaviors, goals
- Secondary users (if applicable)
- User journey map (current state vs. desired state)
- Jobs-to-be-done framework

### Section 5: Product Vision & Scope
From refined concept:
- Product vision statement
- Core value proposition
- In-scope features (from KANO Must-Be + Performance + selected Excitement)
- Explicitly out-of-scope features (from KANO Indifferent + Reverse, with justification)
- Future roadmap items

### Section 6: Feature Specifications (KANO-Classified)
From Phase 6 KANO analysis:

**Must-Be Features (MVP Requirements)**
| Feature | Description | Acceptance Criteria | Priority |
|---------|-------------|-------------------|----------|
| [feature] | [detail] | [specific, testable criteria] | P0 |

**Performance Features**
| Feature | Description | Metric | Target | Priority |
|---------|-------------|--------|--------|----------|
| [feature] | [detail] | [what to measure] | [target] | P1 |

**Excitement Features**
| Feature | Description | Expected Impact | Priority |
|---------|-------------|----------------|----------|
| [feature] | [detail] | [differentiation value] | P2 |

### Section 7: Product Architecture
From Phase 6 morphological chart:
- System architecture overview (components and interactions)
- Technology stack selection with justification
- Component specifications (from morphological chart selections)
- Integration points and dependencies
- Data model (if applicable)

### Section 8: Evaluation Evidence
From Phase 5:
- Rubric score summary (final reconciled score)
- Top-scoring criteria (strengths to leverage)
- Improvement areas addressed in refinement
- Model agreement analysis (Claude vs. Gemini key divergences)
- 20+ concepts considered, evaluation methodology summary

### Section 9: Risk Assessment & Mitigation
Synthesize from all phases:
- Technical risks (from component analysis)
- Market risks (from competitive analysis)
- Execution risks (from self-assessment)
- Financial risks (from resource constraints)
- For each risk: likelihood, impact, mitigation strategy

### Section 10: Success Metrics & KPIs
- Launch metrics (first 30/60/90 days)
- Growth metrics (6-12 months)
- Quality metrics (customer satisfaction, NPS)
- Financial metrics (revenue targets, unit economics)
- How metrics connect to rubric criteria

## Output Format

Generate TWO outputs:

### 1. Markdown Artifact
Save as `product-requirements-document.md` — comprehensive, all sections populated with evidence from prior phases.

### 2. Word Document
Generate a formatted `.docx` file with:
- Professional formatting (headings, tables, page numbers)
- Table of contents
- Executive summary on first page
- All sections with proper numbering
- References/sources cited throughout

## Generation Process

1. Load all 6 prior artifacts into context.
2. For each PRD section, pull specific evidence from the relevant artifact(s).
3. Write each section in professional, third-person business language.
4. Ensure every claim is supported by evidence from the research phases.
5. Cross-reference KANO classifications with feature specifications.
6. Generate both markdown and .docx outputs.
7. Run a final quality check:
   - [ ] All 10 sections complete
   - [ ] Evidence cited for all market claims
   - [ ] KANO classifications consistent between Phase 6 and PRD
   - [ ] Rubric score referenced
   - [ ] 20+ concepts mentioned in evaluation evidence section
   - [ ] Risk assessment covers all major categories
   - [ ] Success metrics are specific and measurable

## Final Deliverable Checklist

Before submission, verify:
- [ ] PRD document (markdown + .docx)
- [ ] Strategic Brief (Phase 1)
- [ ] Evaluation Rubric (Phase 2)
- [ ] Concept Candidates list showing 20+ concepts (Phase 3)
- [ ] Research Repository (Phase 4)
- [ ] Evaluation Results with Pugh Matrix scores (Phase 5)
- [ ] Refined Concept with KANO classification (Phase 6)
- [ ] Progress Tracker showing all phases complete

**Due: February 10, 2026**

## Note

This skill contains a baseline PRD template. It will be updated when the instructor's specialized PRD skill is provided. The current structure covers all required sections identified in the pipeline design.
