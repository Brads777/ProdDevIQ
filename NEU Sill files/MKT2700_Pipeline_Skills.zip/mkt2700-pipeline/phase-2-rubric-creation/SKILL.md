---
name: phase-2-rubric-creation
description: Phase 2 of the MKT2700 AI-Augmented Product Development Pipeline. Creates a weighted evaluation rubric with two pillars — external market criteria (from AI Deep Research) and internal organizational criteria (from team interview). Uses 0-4 scoring scale with defined levels. Enforces weighting BEFORE scoring. Triggers on "begin phase 2," "rubric creation," "evaluation criteria," or "create rubric." Requires Phase 1 Strategic Brief as input.
---

# Phase 2: Rubric Creation

## Purpose

Build a comprehensive, weighted evaluation rubric tailored to the team's specific strategic situation. This rubric will be used in Phase 5 to evaluate all discovered concepts. The rubric has two pillars: external market criteria and internal organizational criteria.

## Prerequisites

Requires the `strategic-brief.md` artifact from Phase 1. If not available, ask the student to provide it.

## Process

### Step 1: External Criteria Discovery (AI Deep Research)

Using web search and the Strategic Brief, research what makes products successful in this specific market. Generate and investigate these questions:

1. "What are the critical success factors for new [industry] products?"
2. "What caused recent product failures in [industry]?"
3. "What do customers in [market segment] value most when choosing products?"
4. "What regulatory or compliance requirements exist for [industry] products?"
5. "What are the emerging trends that successful [industry] products must address?"

Synthesize findings into ~15-20 external criteria. Common categories include:
- Market fit & demand validation
- Competitive differentiation
- Revenue potential / market size
- Customer acquisition feasibility
- Regulatory/compliance alignment
- Technology readiness
- Scalability potential
- Trend alignment

### Step 2: Internal Criteria Interview

Interview the team about organizational capabilities. Ask ONE question at a time:

1. "Based on your Strategic Brief, what are the 3-4 capabilities your team is strongest in?"
2. "What resources are absolutely fixed constraints — budget ceiling, team size, timeline?"
3. "Are there any 'must-have' requirements that should automatically kill a concept if missing? (e.g., must be buildable in 6 months, must cost under $X to develop)"
4. "What technical capabilities does your team have vs. would need to acquire?"
5. "Are there partnership or distribution channels already available?"

Synthesize into ~5-10 internal criteria covering:
- Technical feasibility given team skills
- Budget alignment
- Timeline feasibility
- Resource availability
- Strategic fit with company capabilities (from VRIO)

### Step 3: Compile & Define Criteria

For EACH criterion, create a scoring definition:

```markdown
### [Criterion Name]
**Category:** External / Internal
**Weight:** [to be set in Step 4]

| Score | Level | Definition |
|-------|-------|------------|
| 0 | Non-existent | [specific definition for this criterion] |
| 1 | Weak | [specific definition] |
| 2 | Moderate | [specific definition] |
| 3 | Strong | [specific definition] |
| 4 | Exceptional | [specific definition] |
```

Each level definition must be specific and observable — not vague. Bad: "Somewhat good market fit." Good: "Target market segment identified with evidence of demand from 2+ independent sources, but no direct customer validation yet."

### Step 4: Weight Assignment

**CRITICAL: Weights must be assigned BEFORE any concepts are scored. This prevents gaming the system to favor a preferred concept.**

Present all criteria to the team and ask them to assign relative importance weights. Guide with:

1. "Which criteria are absolutely essential — a score of 0 on these should eliminate a concept regardless of other scores?"
2. "Rank these criteria from most to least important for your company's specific situation."
3. "Assign a weight from 1-5 to each criterion, where 5 = critical and 1 = nice-to-have."

The system suggests initial weights based on the Strategic Brief analysis, then lets the team adjust.

### Step 5: Add Must-Have Constraints

Identify binary pass/fail criteria that act as pre-filters:
- These are not scored on the 0-4 scale
- They are YES/NO gates: if NO, the concept is killed before rubric scoring
- Examples: "Must be legal in target market," "Must be buildable within 12 months," "Must not require >$500K initial investment"

### Step 6: Validate & Lock

Present the complete rubric to the team for review:
- Total criteria count
- Weight distribution (show as % of total weight)
- Must-have constraints list
- Sample scoring walkthrough with a hypothetical concept

Once approved, lock the rubric. No changes after scoring begins.

## Scoring Formula

```
Final Score = (Sum of [score × weight] for all criteria) ÷ (Sum of [4 × weight] for all criteria) × 100%
```

This produces a percentage where 100% = perfect score on every criterion.

## Decision Thresholds

| Score Range | Decision | Action |
|-------------|----------|--------|
| < 90% | **KILL** | Eliminate from consideration |
| 90% – 95% | **REVISE** | Identify improvement opportunities; re-evaluate after changes |
| > 95% | **CONTINUE** | Advance to deep research and refinement |

For concepts in the REVISE band, the system generates improvement suggestions ranked by projected impact on the final score.

## Output: Evaluation Rubric Artifact

Save as `evaluation-rubric.md`:

```markdown
# Evaluation Rubric: [Company Name]

## Must-Have Constraints (Pass/Fail)
1. [Constraint]: YES/NO
2. [Constraint]: YES/NO
...

## Scoring Criteria

### External Criteria
| # | Criterion | Weight | 0 (Non-existent) | 1 (Weak) | 2 (Moderate) | 3 (Strong) | 4 (Exceptional) |
|---|-----------|--------|-------------------|----------|--------------|------------|------------------|
| 1 | [name] | [1-5] | [definition] | [def] | [def] | [def] | [def] |
...

### Internal Criteria
| # | Criterion | Weight | 0 | 1 | 2 | 3 | 4 |
|---|-----------|--------|---|---|---|---|---|
...

## Scoring Formula
Final Score = (Σ score×weight) ÷ (Σ 4×weight) × 100%

## Decision Thresholds
- < 90%: KILL
- 90-95%: REVISE (with improvement roadmap)
- > 95%: CONTINUE

## Total Criteria: [N]
## Total Weight Points: [sum]
## Maximum Possible Score: [sum × 4]
## Rubric Locked: [date]
```

## Handoff

After generating the rubric:
1. Save the artifact.
2. Remind: "Your rubric is now LOCKED. Do not change weights or criteria after this point."
3. Instruct: "Open a new chat and say 'Begin Phase 3.' Bring your progress tracker and Strategic Brief."
